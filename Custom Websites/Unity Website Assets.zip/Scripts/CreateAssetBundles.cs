using UnityEditor;
using UnityEngine;

public class CreateAssetBundles
{
    #if UNITY_EDITOR
        [UnityEditor.MenuItem("Assets/Build AssetBundles")]
        static void BuildAllAssetBundles ()
        {
            BuildPipeline.BuildAssetBundles("Assets/AssetBundles", BuildAssetBundleOptions.None, BuildTarget.StandaloneWindows64);
        }
    #endif
}