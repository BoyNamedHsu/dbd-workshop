using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This script should be attached to the root of each website.
public class Website : MonoBehaviour
{
    // Launches a website of the given url.
    public void LaunchInnerSite(string url) {}

    // Downloads a table of the given name to the player's desktop.
    // Table must be marked as hidden in the config file.
    public void DownloadHiddenTable(string tableName) {}
}
