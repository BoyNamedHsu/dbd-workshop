using UnityEngine;
using UnityEngine.EventSystems;

// Sets the cursor back to normal when the attached object is clicked on.
// This is used for buttons that redirect to new websites.
public class CursorChangerExit : CursorChanger, IPointerClickHandler
{
    public void OnPointerClick(PointerEventData pointerEventData) {}
}
