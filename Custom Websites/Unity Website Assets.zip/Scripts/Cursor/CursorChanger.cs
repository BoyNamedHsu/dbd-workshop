using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Changes the cursor to the finger to indicate that something can be clicked on.
// Add this component to buttons or other clickable elements.
public class CursorChanger : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public void OnPointerEnter(PointerEventData pointerEventData) {}

    public void OnPointerExit(PointerEventData pointerEventData) {}
}
